# geni-tools Contributors

Omni, Stitcher and GCF are very much the product of the entire GENI
community. Contributions have included great feedback from users,
informal suggestions from developers, and complete patches.

Thank you to everyone!

Have a suggestion, feature request, or issue to report? Read about how to [contribute](CONTRIBUTING.md).

Contributors recognized by GitHub are listed [on GitHub](https://github.com/GENI-NSF/geni-tools/graphs/contributors).

Past contributors have included:
 - Alvaro Manuel Recio Perez, University of Malaga
 - David Margery, Inria
 - Tomasz Buchert, Inria
 - Ezra Kissel, Indiana University
 - Nick Bastin, Barnstormer Softworks
 - Hussam Nasir, University of Kentucky
 - Chaos Golubitsky, Raytheon BBN Technologies
 - Mike Thome, Raytheon BBN Technologies
 - Regina Hain, Raytheon BBN Technologies
 - Marshall Brinn, Raytheon BBN Technologies
 - Sarah Edwards, Raytheon BBN Technologies
 - Tom Mitchell, Raytheon BBN Technologies
 - Aaron Helsinger, Raytheon BBN Technologies
 - Eduardo Miravalls Sierra, HPCN Lab of University UAM

Thank you!
