#!/bin/sh

autoreconf --install --force --symlink || exit 1
