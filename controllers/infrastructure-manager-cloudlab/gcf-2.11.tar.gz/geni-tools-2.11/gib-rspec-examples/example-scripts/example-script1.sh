#!/bin/bash

echo "The script 'example-script1.sh' has been installed!"
