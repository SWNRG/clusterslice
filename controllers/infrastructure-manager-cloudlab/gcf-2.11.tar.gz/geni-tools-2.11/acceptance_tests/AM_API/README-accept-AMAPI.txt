See https://github.com/GENI-NSF/geni-tools/wiki/AM-API-Acceptance-Tests
