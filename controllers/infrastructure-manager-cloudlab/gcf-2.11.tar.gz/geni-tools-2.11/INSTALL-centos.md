CentOS 7
--------

```
yum install m2crypto python-dateutil pyOpenSSL \
            xmlsec1 xmlsec1-openssl
```

CentOS 6
--------

```
yum install m2crypto python-dateutil pyOpenSSL \
            xmlsec1 xmlsec1-openssl python-importlib
```
